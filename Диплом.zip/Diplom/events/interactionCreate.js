const { MessageEmbed, Modal, TextInputComponent, MessageActionRow, MessageSelectMenu, MessageButton, MessageAttachment} = require('discord.js')
module.exports = {
    name: 'interactionCreate',
    once: false,
    async execute(client, interaction) {

    if(interaction.isSelectMenu()) {
        const value = interaction.values[0]
        if(interaction.customId === `class`) {
        if(value === `one`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`11 класс`)
            .setImage(`https://i.imgur.com/pN2fKR7.png`)
            return interaction.update({ embeds: [embed] })
        }
        if(value === `two`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`9 класс`)
            .setImage(`https://i.imgur.com/MxUCY7u.png`)
            return interaction.update({ embeds: [embed] })
    }}}

    if(interaction.isSelectMenu()) {
        const value = interaction.values[0]
        if(interaction.customId === `opisanie`) {
        if(value === `master1`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Мастер сухого строительства`)
            .setImage(`https://i.imgur.com/aBtu5MA.png`)
            .setDescription('Выполнение каркасно-обшивных конструкций, включая подготовительные работы, их ремонт. Обустройство сборных оснований пола, отделка конструкций готовыми составами и сухими строительными смесями. Монтаж конструкций из гипсовых пазогребневых плит, бескаркасных облицовок стен. Выполнение облицовочных работ различных поверхностей помещений, зданий и сооружений, их ремонт. Создание декоративных и художественных мозаичных поверхностей с применением облицовочной плитки.')
            return interaction.update({ embeds: [embed] })
        }
        if(value === `master2`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Мастер жилищнокоммунального хозяйства`)
            .setImage(`https://i.imgur.com/AKI3tJr.png`)
            .setDescription('Выполнение работ по эксплуатации и ремонту оборудования систем водоснабжения, водоотведения, отопления жилищно-коммунального хозяйства. Выполнение электрогазосварочных работ при ремонте оборудования систем водоснабжения, водоотведения и отопления. Выполнение работ по монтажу, эксплуатации и ремонту электросиловых, слаботочных и осветительных сетей объектов жилищнокоммунального хозяйства.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `electromontaz`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Электромонтажник электрических сетей и оборудования`)
            .setImage(`https://i.imgur.com/hBs6SSv.png`)
            .setDescription('Монтаж осветительных электропроводок и оборудования. Монтаж кабельных сетей. Монтаж распределительных устройств и вторичных цепей.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `montaz`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Монтажник технологического оборудования`)
            .setImage(`https://i.imgur.com/QyWnM1I.png`)
            .setDescription('Проведение монтажа и ремонта промышленного оборудования. Обслуживание промышленного оборудования. Контроль результатов монтажных, ремонтных работ и обслуживания промышленного оборудования.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `architecture`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Архитектура`)
            .setImage(`https://i.imgur.com/vEOtzPl.png`)
            .setDescription('Проектирование объектов архитектурной среды. Осуществление мероприятий по реализации принятых проектных решений. Планирование и организация процесса архитектурного проектирования.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `stroitel`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Строительство и экплуатация зданий и сооружений`)
            .setImage(`https://i.imgur.com/p21jhMq.png`)
            .setDescription('Участие в проектировании зданий и сооружений. Выполнение технологических процессов при строительстве, эксплуатации и реконструкции строительных объектов. Организация деятельности структурных подразделений при выполнении строительно-монтажных работ, эксплуатации и реконструкции зданий и сооружений. Организация работ при эксплуатации и реконструкции строительных объектов.')
            return interaction.update({ embeds: [embed] })
        }
        if(value === `komputer`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Компьютерные системы и комплексы`)
            .setImage(`https://i.imgur.com/RdVELJM.png`)
            .setDescription('Проектирование цифровых устройств. Применение микропроцессорных систем, установка и настройка периферийного оборудования. Техническое обслуживание и ремонт компьютерных систем и комплексов.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `infosis`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Информационные системы и программирование`)
            .setImage(`https://i.imgur.com/zCZHUWQ.png`)
            .setDescription('Осуществление интеграции программных модулей. Ревьюирование программных продуктов. Проектирование и разработка информационных систем. Сопровождение информационных систем. Соадминистрирование баз данных и серверов.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `techradio`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Техническое обслуживание и ремонт радиоэлектронной техники`)
            .setImage(`https://i.imgur.com/D8cF0tg.png`)
            .setDescription('Сборка, монтаж устройств, блоков и приборов различных видов радиоэлектронной техники. Настройка, регулировка и проведение испытаний устройств, блоков и приборов радиоэлектронной техники. Проведение диагностики и ремонта различных видов радиоэлектронной техники.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `techelectro`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Техническая экплуатация и обслуживание электрического и электромеханического оборудования`)
            .setImage(`https://i.imgur.com/TXkRZO9.png`)
            .setDescription('Организация технического обслуживания и ремонта оборудования. Выполнение сервисного обслуживания бытовых машин и приборов. Организация деятельности производственного подразделения. Выполнение работ по профессиям "Слесарь-электрик" и "Электромонтер".')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `metallurg`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Металлургия цветных металлов`)
            .setImage(`https://i.imgur.com/XzBNAzg.png`)
            .setDescription('Ведение технологического процесса производства цветных металлов и сплавов. Обслуживание основного и вспомогательного технологического оборудования. Выполнение работ по профессии "Аппаратчик-гидрометаллург".')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `pravo`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Право и организация социального обеспечения`)
            .setImage(`https://i.imgur.com/EahIUJ3.png`)
            .setDescription('Обеспечение реализации прав граждан в сфере пенсионного обеспечения и социальной защиты. Организационное обеспечение деятельности учреждений социальной защиты населения и органовы Пенсионного фонда РФ. Основы оперативного обеспечения деятельности правоохранительных органов РФ.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `ekonomika`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Экономика и бухгалтерский учет`)
            .setImage(`https://i.imgur.com/XNq9d6m.png`)
            .setDescription('Учет имущества и обязательств организации. Проведение и оформление хозяйственных операций. Обработка бухгалтерской информации, проведение расчетов с бюджетом и внебюджетными фондами. Формирование бухгалтерской отчетности, налоговый учет, налоговое планирование.')
            return interaction.update({ embeds: [embed] })
    }
    }}
        if(interaction.isSelectMenu()) {
        const value = interaction.values[0]
        if(interaction.customId === `pripisanie`) {
        if(value === `social`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Социальный работник`)
            .setImage(`https://i.imgur.com/gXBuFEt.png`)
            .setDescription('Система организации социальной работы в РФ. Этика взаимоотношений, деловое общение, охрана труда. Деятельность органов социальной защиты региона.')
            return interaction.update({ embeds: [embed] })
        }
        if(value === `mcm`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Металлургия цветных металлов`)
            .setImage(`https://i.imgur.com/XzBNAzg.png`)
            .setDescription('Ведение технологического процесса производства цветных металлов и сплавов. Обслуживание основного и вспомогательного технологического оборудования. Выполнение работ по профессии "Аппаратчик-гидрометаллург".')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `stroitelstvo`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Строительство и эксплуатация зданий и сооружений`)
            .setImage(`https://i.imgur.com/p21jhMq.png`)
            .setDescription('Участие в проектировании зданий и сооружений. Выполнение технологических процессов при строительстве, эксплуатации и реконструкции строительных объектов. Организация деятельности структурных подразделений при выполнении строительно-монтажных работ, эксплуатации и реконструкции зданий и сооружений. Организация работ при эксплуатации и реконструкции строительных объектов.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `montazsanteh`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Монтаж и эксплуатация внутренних сантехнических устройств, кондиционирования воздуха и вентиляции`)
            .setImage(`https://i.imgur.com/fiwmey5.png`)
            .setDescription('Инженерная графика, техническая механика, электротехника и электроника, материалы и изделия сантехнических устройств и систем обеспечения микроклимата. Организация и контроль работ по монтажу систем водоснабжения и водоотведения, отопления, вентиляции и кондиционирования воздухарганизация и контроль работ по монтажу систем водоснабжения и водоотведения, отопления, вентиляции и кондиционирования воздуха. Участие в проектировании систем водоснабжения и водоотведения, отопления, вентиляции и кондиционирования воздуха.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `rzd`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Строительство железных дорог, путь и путевое хозяйство`)
            .setImage(`https://i.imgur.com/ojUY6GI.png`)
            .setDescription('Участие в проектировании и строительстве железных дорог, зданий и сооружений. Ремонт и строительство железнодорожного пути с использованием средств механизации. Разбивка на местности элементов железнодорожного пути и искусственных сооружений для строительства железных дорог. Различные виды геодезических съемок и обработка их материалов.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `ks`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Компьютерные системы и комплексы`)
            .setImage(`https://i.imgur.com/RdVELJM.png`)
            .setDescription('Проектирование цифровых устройств. Применение микропроцессорных систем, установка и настройка периферийного оборудования. Техническое обслуживание и ремонт компьютерных систем и комплексов.')
            return interaction.update({ embeds: [embed] })
        }
        if(value === `radiotehnik`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Техническое обслуживание и ремонт радиоэлектронной техники`)
            .setImage(`https://i.imgur.com/D8cF0tg.png`)
            .setDescription('Сборка, монтаж устройств, блоков и приборов различных видов радиоэлектронной техники. Настройка, регулировка и проведение испытаний устройств, блоков и приборов радиоэлектронной техники. Проведение диагностики и ремонта различных видов радиоэлектронной техники.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `electromehanik`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Техническая эксплуатация и обслуживание электрического и электромеханического оборудования`)
            .setImage(`https://i.imgur.com/TXkRZO9.png`)
            .setDescription('Организация технического обслуживания и ремонта оборудования. Выполнение сервисного обслуживания бытовых машин и приборов. Организация деятельности производственного подразделения. Выполнение работ по профессиям "Слесарь-электрик" и "Электромонтер".')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `ekonomist`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Экономика и бухгалтерский учет`)
            .setImage(`https://i.imgur.com/XNq9d6m.png`)
            .setDescription('Учет имущества и обязательств организации. Проведение и оформление хозяйственных операций. Обработка бухгалтерской информации, проведение расчетов с бюджетом и внебюджетными фондами. Формирование бухгалтерской отчетности, налоговый учет, налоговое планирование.')
            return interaction.update({ embeds: [embed] })
    }
        if(value === `pravoorg`) {
            const embed = new MessageEmbed()
            .setColor(`2B2D31`)
            .setTitle(`Право и организация социального обеспечения`)
            .setImage(`https://i.imgur.com/EahIUJ3.png`)
            .setDescription('Обеспечение реализации прав граждан в сфере пенсионного обеспечения и социальной защиты. Организационное обеспечение деятельности учреждений социальной защиты населения и органовы Пенсионного фонда РФ. Основы оперативного обеспечения деятельности правоохранительных органов РФ.')
            return interaction.update({ embeds: [embed] })
    }
    }}}
    }
