const { MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

module.exports = {
  name: "abiturent",
  description: "Показывает доступные специальности на базе выбранных классов",
  run: async (client, interaction, args) => {
    const row = new MessageActionRow()
    .addComponents(new MessageSelectMenu()
    .setCustomId(`class`)
    .setPlaceholder(`Выберите оконченный класс`)
    .addOptions(
      {
        label: `11 класс`,
        value: "one"
      },
      {
        label: `9 класс`,
        value: "two"
      }
    ))
    return interaction.reply({ components: [row], ephemeral: true })
    }}
