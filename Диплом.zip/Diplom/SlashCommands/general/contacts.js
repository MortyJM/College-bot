const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'contacts',
  description: 'Показывает контакты, адрес и график работы колледжа',
  run: async (client, interaction, args) => {
    const row = new MessageEmbed()
      .setTitle('Информация о колледже')
      .setColor('2B2D31')
      .setImage('https://i.imgur.com/WhKXpFB.png')
      .setDescription('Номер телефона колледжа: 8 (39151) 7-13-06. Приемная комиссия: г. Ачинск, ул. Гагарина 27, каб. 111. График работы: Пн-Пт: с 9.00 до 18.00 Сб: с 9.00 до 12.00. Сайт коллдежа: http://agkotib.ru/. Группа VK колледжа: https://akotib123.');

    return interaction.reply({ embeds: [row], ephemeral: true })
  },
};