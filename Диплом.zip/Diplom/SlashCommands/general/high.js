const { MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

module.exports = {
  name: "info11",
  description: "Показывает описание специальностей на базе 11 классов",
  run: async (client, interaction, args) => {
    const row = new MessageActionRow()
    .addComponents(new MessageSelectMenu()
    .setCustomId(`pripisanie`)
    .setPlaceholder(`Выберите специальность на базе 11 классов`)
    .addOptions(
      {
        label: `Социальный работник`,
        value: "social"
      },
      {
        label: `Металлургия цветных металлов`,
        value: "mcm"
      },
      {
        label: `Строительство и эксплуатация зданий и сооружений`,
        value: "stroitelstvo"
      },
      {
        label: `Монтаж и эксплуатация внутренних сантехнических устройств, кондиционирования воздуха и вентиляции`,
        value: "montazsanteh"
      },
      {
        label: `Строительство железных дорог, путь и путевое хозяйство`,
        value: "rzd"
      },
      {
        label: `Компьютерные системы и комплексы`,
        value: "ks"
      },
      {
        label: `Техническое обслуживание и ремонт радиоэлектронной техники`,
        value: "radiotehnik"
      },
      {
        label: `Техническая эксплуатация и обслуживание электрического и электромеханического оборудования`,
        value: "electromehanik"
      },
      {
        label: `Экономика и бухгалтерский учет`,
        value: "ekonomist"
      },
      {
        label: `Право и организация социального обеспечения`,
        value: "pravoorg"
      }
    ))
    return interaction.reply({ components: [row], ephemeral: true })
    }}