const { MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

module.exports = {
  name: "info9",
  description: "Показывает описание специальностей на базе 9 классов",
  run: async (client, interaction, args) => {
    const row = new MessageActionRow()
    .addComponents(new MessageSelectMenu()
    .setCustomId(`opisanie`)
    .setPlaceholder(`Выберите специальность на базе 9 классов`)
    .addOptions(
      {
        label: `Мастер сухого строительства`,
        value: "master1"
      },
      {
        label: `Мастер жилищнокоммунального хозяйства`,
        value: "master2"
      },
      {
        label: `Электромонтажник электрических сетей и оборудования`,
        value: "electromontaz"
      },
      {
        label: `Монтажник технологического оборудования`,
        value: "montaz"
      },
      {
        label: `Архитектура`,
        value: "architecture"
      },
      {
        label: `Строительство и экплуатация зданий и сооружений`,
        value: "stroitel"
      },
      {
        label: `Компьютерные системы и комплексы`,
        value: "komputer"
      },
      {
        label: `Информационные системы и программирование`,
        value: "infosis"
      },
      {
        label: `Техническое обслуживание и ремонт радиоэлектронной техники`,
        value: "techradio"
      },
      {
        label: `Техническая экплуатация и обслуживание электрического и электромеханического оборудования`,
        value: "techelectro"
      },
      {
        label: `Металлургия цветных металлов`,
        value: "metallurg"
      },
      {
        label: `Право и организация социального обеспечения`,
        value: "pravo"
      },
      {
        label: `Экономика и бухгалтерский учет`,
        value: "ekonomika"
      }
    ))
    return interaction.reply({ components: [row], ephemeral: true })
    }}