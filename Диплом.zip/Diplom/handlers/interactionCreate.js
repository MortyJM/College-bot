module.exports =  async (client) => {
    await interaction.editReply({ ephemeral: true }).catch(() => { });
    if (interaction.isCommand()) {
        const cmd = client.slashCommands.get(interaction.commandName);
        if (!cmd)
            return interaction.followUp({ content: "An error has occured " });
            await client.CreateAndUpdate(interaction.guild.id, interaction.user.id) /// Can find this module in Handlers/loadCreate.js
            await client.AuctionCreateAndUpdate(interaction.guild.id)
            await client.Roulette(interaction.guild.id)
            await client.Coinflip(interaction.guild.id)
            await client.Level(interaction.guild.id, interaction.user.id) 
    
            if (!client.dev.includes(interaction.user.id) && client.dev.length > 0) { 
                interaction.reply(`You are not allowed to use this command.`); 
                return;
            }
        const args = [];
        for (let option of interaction.options.data) {
            if (option.type === "SUB_COMMAND") {
                if (option.name) args.push(option.name);
                option.options?.forEach((x) => {
                    if (x.value) args.push(x.value);
                });
            } else if (option.value) args.push(option.value);
        }
        interaction.member = interaction.guild.members.cache.get(interaction.user.id);

        cmd.run(client, interaction, args);
    }


    if (interaction.isContextMenu()) {
        await interaction.editReply({ ephemeral: true });
        const command = client.slashCommands.get(interaction.commandName);
        if (command) command.run(client, interaction);
    }
}